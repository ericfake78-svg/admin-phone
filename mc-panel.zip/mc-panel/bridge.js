/**
 * MC Panel — RCON Bridge
 * ──────────────────────
 * Connects to your Minecraft server via RCON and exposes
 * a local HTTP API that the panel uses.
 *
 * Setup:
 *   1. npm install  (installs dependencies)
 *   2. Edit CONFIG below, or use environment variables
 *   3. node bridge.js
 *   4. Open index.html and click Connect → http://localhost:3000
 *
 * server.properties requirements:
 *   enable-rcon=true
 *   rcon.port=25575
 *   rcon.password=yourpassword
 *   broadcast-rcon-to-ops=false   (optional, reduces log noise)
 */

const http   = require('http');
const net    = require('net');
const crypto = require('crypto');

// ─── CONFIG ──────────────────────────────────────────────────────────
const CONFIG = {
  rconHost:     process.env.RCON_HOST     || '127.0.0.1',
  rconPort:     parseInt(process.env.RCON_PORT)     || 25575,
  rconPassword: process.env.RCON_PASSWORD || 'changeme',
  bridgePort:   parseInt(process.env.BRIDGE_PORT)   || 3000,
  // CORS: set to your panel URL if you host it remotely, or '*' for open
  corsOrigin:   process.env.CORS_ORIGIN   || '*',
};
// ─────────────────────────────────────────────────────────────────────

// ─── RCON protocol ───────────────────────────────────────────────────
const RCON_AUTH       = 3;
const RCON_COMMAND    = 2;
const RCON_AUTH_RESP  = 2;

let rconSocket   = null;
let rconAuthed   = false;
let pendingReqs  = new Map();   // id → { resolve, reject, timer }
let recvBuf      = Buffer.alloc(0);

function makePacket(id, type, body) {
  const bodyBuf = Buffer.from(body, 'utf8');
  const size = 4 + 4 + bodyBuf.length + 2; // id(4) + type(4) + body + 2 nulls
  const pkt  = Buffer.alloc(4 + size);
  pkt.writeInt32LE(size,         0);
  pkt.writeInt32LE(id,           4);
  pkt.writeInt32LE(type,         8);
  bodyBuf.copy(pkt,              12);
  pkt.writeUInt8(0, 12 + bodyBuf.length);
  pkt.writeUInt8(0, 13 + bodyBuf.length);
  return pkt;
}

function parsePackets(buf) {
  const packets = [];
  while (buf.length >= 14) {
    const size = buf.readInt32LE(0);
    if (buf.length < size + 4) break;
    const id   = buf.readInt32LE(4);
    const type = buf.readInt32LE(8);
    const body = buf.slice(12, 4 + size - 2).toString('utf8');
    packets.push({ id, type, body });
    buf = buf.slice(4 + size);
  }
  return { packets, remaining: buf };
}

function connectRcon() {
  return new Promise((resolve, reject) => {
    if (rconSocket && rconAuthed) { resolve(); return; }
    if (rconSocket) { rconSocket.destroy(); rconSocket = null; rconAuthed = false; }

    const sock = net.createConnection(CONFIG.rconPort, CONFIG.rconHost);
    rconSocket = sock;
    rconAuthed = false;
    recvBuf = Buffer.alloc(0);

    const authId = 1;
    let authResolve = resolve;
    let authReject  = reject;
    let authTimer   = setTimeout(() => authReject(new Error('RCON auth timeout')), 8000);

    sock.on('connect', () => {
      sock.write(makePacket(authId, RCON_AUTH, CONFIG.rconPassword));
    });

    sock.on('data', (chunk) => {
      recvBuf = Buffer.concat([recvBuf, chunk]);
      const { packets, remaining } = parsePackets(recvBuf);
      recvBuf = remaining;
      for (const pkt of packets) {
        if (!rconAuthed) {
          clearTimeout(authTimer);
          if (pkt.id === -1) { authReject(new Error('RCON auth failed — wrong password?')); sock.destroy(); return; }
          rconAuthed = true;
          console.log(`✅  RCON connected to ${CONFIG.rconHost}:${CONFIG.rconPort}`);
          authResolve();
        } else {
          const pending = pendingReqs.get(pkt.id);
          if (pending) {
            clearTimeout(pending.timer);
            pendingReqs.delete(pkt.id);
            pending.resolve(pkt.body);
          }
        }
      }
    });

    sock.on('error', (err) => {
      console.error('RCON socket error:', err.message);
      rconSocket = null; rconAuthed = false;
      if (authResolve) { authReject(err); authResolve = null; }
      pendingReqs.forEach(p => p.reject(err));
      pendingReqs.clear();
    });

    sock.on('close', () => {
      rconSocket = null; rconAuthed = false;
    });
  });
}

function rconCommand(cmd) {
  return new Promise(async (resolve, reject) => {
    try {
      await connectRcon();
    } catch(e) { return reject(e); }

    const id    = (Date.now() & 0x7fffffff) || 2;
    const timer = setTimeout(() => {
      pendingReqs.delete(id);
      reject(new Error('Command timeout'));
    }, 10000);
    pendingReqs.set(id, { resolve, reject, timer });
    rconSocket.write(makePacket(id, RCON_COMMAND, cmd));
  });
}

// ─── Parse /list output ───────────────────────────────────────────────
// Vanilla: "There are 2 of a max of 20 players online: Steve, Alex"
function parseList(raw) {
  const m = raw.match(/There are (\d+) of a max of (\d+) players online:(.*)/i);
  if (!m) return { count: 0, max: 20, names: [] };
  const names = m[3].split(',').map(s => s.trim()).filter(Boolean);
  return { count: parseInt(m[1]), max: parseInt(m[2]), names };
}

// ─── HTTP server ──────────────────────────────────────────────────────
function cors(res) {
  res.setHeader('Access-Control-Allow-Origin',  CONFIG.corsOrigin);
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
}

function json(res, data, code = 200) {
  cors(res);
  res.writeHead(code, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify(data));
}

function err(res, msg, code = 500) {
  json(res, { error: msg }, code);
}

const server = http.createServer(async (req, res) => {
  cors(res);
  if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return; }

  const url = req.url.split('?')[0];

  // ── GET /ping ──────────────────────────────────────────────────────
  if (req.method === 'GET' && url === '/ping') {
    try {
      await connectRcon();
      json(res, { ok: true });
    } catch(e) {
      err(res, e.message, 503);
    }
    return;
  }

  // ── GET /players ───────────────────────────────────────────────────
  if (req.method === 'GET' && url === '/players') {
    try {
      await connectRcon();
      const raw = await rconCommand('list');
      const { count, max, names } = parseList(raw);
      // Build player objects — ping needs Paper/Spigot or a plugin
      const players = names.map(name => ({
        name,
        op: false,   // would need to read ops.json
        ping: null,  // Paper exposes via /ping <player>
        world: null,
      }));
      json(res, { players, maxPlayers: max, count });
    } catch(e) {
      err(res, e.message);
    }
    return;
  }

  // ── GET /stats ─────────────────────────────────────────────────────
  if (req.method === 'GET' && url === '/stats') {
    try {
      await connectRcon();
      // These work on vanilla; TPS needs Paper (/tps)
      let tps = '—', memMB = '—', uptime = '—';
      try {
        const tpsRaw = await rconCommand('tps');  // Paper only
        const m = tpsRaw.match(/([\d.]+)/);
        if (m) tps = parseFloat(m[1]).toFixed(1);
      } catch(_) {}
      json(res, { tps, memMB, uptime });
    } catch(e) {
      err(res, e.message);
    }
    return;
  }

  // ── POST /command ──────────────────────────────────────────────────
  if (req.method === 'POST' && url === '/command') {
    let body = '';
    req.on('data', c => body += c);
    req.on('end', async () => {
      try {
        const { command } = JSON.parse(body);
        if (!command || typeof command !== 'string') { err(res, 'Missing command', 400); return; }
        await connectRcon();
        const response = await rconCommand(command);
        json(res, { response });
      } catch(e) {
        err(res, e.message);
      }
    });
    return;
  }

  res.writeHead(404); res.end('Not found');
});

server.listen(CONFIG.bridgePort, '0.0.0.0', () => {
  console.log('');
  console.log('╔══════════════════════════════════════════╗');
  console.log('║         MC Panel — RCON Bridge           ║');
  console.log('╠══════════════════════════════════════════╣');
  console.log(`║  Bridge listening on port ${CONFIG.bridgePort}          ║`);
  console.log(`║  RCON target: ${CONFIG.rconHost}:${CONFIG.rconPort}             ║`);
  console.log('╠══════════════════════════════════════════╣');
  console.log('║  Open index.html in your browser        ║');
  console.log(`║  Connect URL: http://localhost:${CONFIG.bridgePort}      ║`);
  console.log('╚══════════════════════════════════════════╝');
  console.log('');
});

// Try connecting on startup so errors surface immediately
connectRcon()
  .then(() => console.log('RCON auth OK — ready to accept panel connections\n'))
  .catch(e  => {
    console.warn('⚠️  RCON pre-connect failed:', e.message);
    console.warn('    (Will retry on first panel request)\n');
  });
