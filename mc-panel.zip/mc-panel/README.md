# MC Panel

A simple Minecraft server admin panel — works on phone and PC.

---

## Setup (5 minutes)

### 1. Enable RCON on your Minecraft server

Edit `server.properties`:

```
enable-rcon=true
rcon.port=25575
rcon.password=YourStrongPassword
```

Restart your server.

---

### 2. Run the bridge (on the same machine as your server)

You need Node.js installed (https://nodejs.org — any recent version).

```bash
# Edit bridge.js and change these 3 lines near the top:
#   rconHost:     '127.0.0.1'   ← your server IP (127.0.0.1 if local)
#   rconPort:     25575          ← your rcon.port
#   rconPassword: 'changeme'     ← your rcon.password

node bridge.js
```

Or use environment variables:
```bash
RCON_PASSWORD=mypassword RCON_HOST=192.168.1.10 node bridge.js
```

---

### 3. Open the panel

Open `index.html` in any browser — Chrome, Safari, Firefox, mobile browser.

- Click **Connect**
- Bridge URL: `http://localhost:3000` (default)
- Click **Connect**

Done ✅

---

## Remote access (phone over WiFi / internet)

If you want to open the panel on your phone or another device:

**Option A — same network (easiest)**
Run bridge.js on the server machine. On your phone, go to:
`http://YOUR_SERVER_LOCAL_IP:3000`

**Option B — anywhere on the internet**
Put `index.html` on any static host (GitHub Pages, Netlify, Cloudflare Pages — all free).
Run bridge.js and expose port 3000 via a tunnel:

```bash
# Free option — ngrok
npx ngrok http 3000
# It gives you a URL like https://abc123.ngrok.io
# Use that as your Bridge URL in the panel
```

---

## Panel features

| Feature | How |
|---|---|
| Console | Type any command, hit Enter or Send |
| Command history | ↑ / ↓ arrows in console input |
| List players | Players tab, auto-refreshes every 5s |
| Kick player | Click ⚡ or right-click → Kick |
| Ban player | Click 🚫 or right-click → Ban |
| IP ban | Right-click → IP ban |
| Send message | Click 💬 next to a player |
| Teleport to spawn | Click 📍 next to a player |
| Broadcast | Stats tab → Broadcast message |
| Save world | Stats tab → Save world |
| Quick commands | Stats tab |

---

## Notes

- **TPS stat** only works on Paper/Spigot servers (not vanilla).
- **Ping per player** requires Paper or a plugin that exposes it via RCON.
- The bridge uses only Node.js built-in modules — no npm install needed.
- RCON sends commands as plain text on your local network. For internet use, always go through a tunnel (ngrok) or VPN — never expose port 25575 directly to the internet.
